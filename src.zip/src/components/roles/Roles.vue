<template src="./template.html"></template>
<script src="./script.js"></script>
<style src="./style.less" lang="less"></style>
